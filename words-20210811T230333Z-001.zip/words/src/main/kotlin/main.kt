import java.io.File
import java.io.BufferedReader


fun main() {
//    val listWords = readFileAsLinesUsingUseLines("stopwords.txt")
    val s = readInput(" go to the bench")
    println(s)

}
fun readFileAsLinesUsingUseLines(fileName: String): List<String>
        = File(fileName).useLines { it.toList() }

fun readInput(command: String): StringBuilder {
    println(command)
    val listWords = readFileAsLinesUsingUseLines("stopwords.txt")
    val s = command.split(" ")
    val builder = StringBuilder()
    for (item: String in s) {
        if (!listWords.contains(item)) {
            builder.append(item)
            builder.append(" ")
        }
    }
    return builder
}
fun ngram(n: Int, inPut: String, outPut: String): Double {
    if (inPut==null) {
        throw NullPointerException("inPut must not be none")
    } else if (outPut==null) {
        throw java.lang.NullPointerException("outPut must not be none")
    } else if (inPut.equals(outPut)) {
        return 1.0;
    } else {


    }
}


