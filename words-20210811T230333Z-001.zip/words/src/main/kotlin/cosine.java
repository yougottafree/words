public class cosine {
}
