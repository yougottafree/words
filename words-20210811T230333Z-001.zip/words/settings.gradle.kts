
rootProject.name = "words"
include("jar_files")



